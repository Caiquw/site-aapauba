// ============================================================
// CONFIGURAÇÃO DO SUPABASE
// ============================================================
// Pegue esses dois valores em: supabase.com > seu projeto >
// Project Settings > API
//   - Project URL          -> SUPABASE_URL
//   - anon / public key    -> SUPABASE_ANON_KEY
//
// A "anon key" é segura para expor no front-end: ela só
// consegue fazer o que as políticas de RLS (Row Level Security)
// permitirem. NUNCA coloque aqui a "service_role key".
// ============================================================

const SUPABASE_URL = "https://SEU-PROJETO.supabase.co";
const SUPABASE_ANON_KEY = "SUA-CHAVE-ANON-PUBLICA";

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Número de WhatsApp da equipe que recebe os pedidos de adoção/informações
// Formato: código do país + DDD + número, só dígitos (sem espaços, +, ( ) ou -)
const WHATSAPP_NUMBER = "5516991106370";
